package com.lody.virtual.helper.compat;

import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.os.IInterface;

import android.util.Log;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import mirror.android.app.ActivityManagerNative;
import mirror.android.app.IActivityManager;
import mirror.android.app.IActivityManagerN;
import mirror.android.util.Singleton;

/**
 * Since Android 10 (API 29) the activity related calls were moved out of
 * {@code IActivityManager} into {@code IActivityTaskManager}:
 * {@code startActivity}, {@code startActivities}, {@code getTaskForActivity},
 * {@code finishActivity}, ...
 * <p>
 * The mirror classes only know the old {@code IActivityManager} versions, so on
 * API 29+ those mirror fields are {@code null} and every call through them
 * throws a NullPointerException (which is what made every guest activity
 * launch die). This class resolves the methods on the right interface.
 */
public final class ActivityTaskCompat {

    private static final String TAG = "ActivityTaskCompat";

    private ActivityTaskCompat() {
    }

    public static boolean useTaskManager() {
        return Build.VERSION.SDK_INT >= 29;
    }

    /**
     * @return {@code ActivityTaskManager.getService()} (API 29+), or {@code null}.
     */
    public static IInterface getService() {
        try {
            Class<?> atm = Class.forName("android.app.ActivityTaskManager");
            Method getService = atm.getDeclaredMethod("getService");
            getService.setAccessible(true);
            return (IInterface) getService.invoke(null);
        } catch (Throwable e) {
            Log.e(TAG, "ActivityTaskManager.getService() failed", e);
            return null;
        }
    }

    /**
     * Replace the instance cached by {@code ActivityTaskManager.IActivityTaskManagerSingleton}.
     * Replacing only the binder in ServiceManager's cache is not enough when the
     * singleton was already created.
     */
    public static void replaceSingletonInstance(Object proxy) throws Throwable {
        Class<?> atm = Class.forName("android.app.ActivityTaskManager");
        java.lang.reflect.Field f = atm.getDeclaredField("IActivityTaskManagerSingleton");
        f.setAccessible(true);
        Object singleton = f.get(null);
        if (singleton != null) {
            Singleton.mInstance.set(singleton, proxy);
        }
    }

    public static Method findMethod(Class<?> clazz, String name) {
        if (clazz == null) {
            return null;
        }
        for (Method m : clazz.getMethods()) {
            if (m.getName().equals(name)) {
                m.setAccessible(true);
                return m;
            }
        }
        for (Method m : clazz.getDeclaredMethods()) {
            if (m.getName().equals(name)) {
                m.setAccessible(true);
                return m;
            }
        }
        return null;
    }

    /**
     * The interface that owns startActivity/startActivities/... on this device.
     */
    public static Object getStartService() {
        if (useTaskManager()) {
            return getService();
        }
        return ActivityManagerNative.getDefault.call();
    }

    public static Method getStartActivityMethod(Object service) {
        return findMethod(service.getClass(), "startActivity");
    }

    public static Method getStartActivitiesMethod(Object service) {
        return findMethod(service.getClass(), "startActivities");
    }

    public static int getTaskForActivity(IBinder token, boolean onlyRoot) {
        try {
            if (useTaskManager()) {
                Object service = getService();
                Method m = findMethod(service.getClass(), "getTaskForActivity");
                return (Integer) m.invoke(service, token, onlyRoot);
            }
            Integer id = IActivityManager.getTaskForActivity.call(
                    ActivityManagerNative.getDefault.call(), token, onlyRoot);
            return id == null ? -1 : id;
        } catch (InvocationTargetException e) {
            Log.e(TAG, "getTaskForActivity failed", e.getCause());
        } catch (Throwable e) {
            Log.e(TAG, "getTaskForActivity failed", e);
        }
        return -1;
    }

    public static boolean finishActivity(IBinder token, int code, Intent data) {
        if (useTaskManager()) {
            try {
                Object service = getService();
                Method m = findMethod(service.getClass(), "finishActivity");
                // boolean finishActivity(IBinder token, int code, Intent data, int finishTask)
                return (Boolean) m.invoke(service, token, code, data, 0);
            } catch (Throwable e) {
                Log.e(TAG, "finishActivity failed", e);
                return false;
            }
        }
        Boolean r = IActivityManagerN.finishActivity.call(
                ActivityManagerNative.getDefault.call(), token, code, data, 0);
        return r != null && r;
    }
}
